# LabStock – Inventory Laboratorium

Aplikasi HP (PWA) untuk mendata barang laboratorium: stok, **barang masuk**, **pemakaian**, vendor, dan monitor stok. Bisa di-install ke layar utama HP, jalan **offline**, dan data tersimpan di HP.

## Fitur
- **Beranda**: ringkasan *masuk hari ini*, *terpakai hari ini*, stok menipis, dan kedaluwarsa.
- **Barang**: tambah/ubah/hapus, foto, kode (Item ID), kategori, satuan, stok minimum, lokasi, tanggal kedaluwarsa, vendor.
- **Riwayat**: semua transaksi masuk/terpakai, dikelompokkan per hari dengan total harian, filter jenis dan tanggal.
- **Monitor**: level stok, grafik 7 hari, barang paling banyak dipakai, daftar kedaluwarsa, stok per vendor.
- **Vendor**: data kontak pemasok.
- **Scan barcode/QR** untuk mencari barang (Chrome Android).
- **Backup/Pulihkan** (JSON) dan **ekspor CSV** (bisa dibuka di Excel).
- Mode gelap otomatis.

## Cara upload ke GitHub dan install ke HP
1. Buat repository baru di GitHub (mis. `labstock`), set **Public**.
2. Upload **semua isi folder ini** (termasuk folder `css`, `js`, `icons`, `.github`, dan file `.nojekyll`). Di web GitHub: *Add file → Upload files*, lalu tarik semua file dan folder.
3. Buka **Settings → Pages → Build and deployment → Source**, pilih **GitHub Actions** (workflow sudah disediakan di `.github/workflows/pages.yml`). Alternatif: pilih *Deploy from a branch* → `main` → `/ (root)`.
4. Tunggu 1–2 menit. Alamat aplikasi: `https://USERNAME.github.io/labstock/`
5. Buka alamat itu di HP:
   - **Android (Chrome)**: menu ⋮ → **Instal aplikasi** (atau tombol *Install aplikasi* di menu Pengaturan aplikasi).
   - **iPhone (Safari)**: tombol Bagikan → **Tambah ke Layar Utama**.

> Catatan: PWA harus dibuka lewat HTTPS (GitHub Pages sudah HTTPS). Membuka `index.html` langsung dari file manager tidak bisa di-install.

## Cara pakai singkat
1. Menu ☰ (kanan atas) → isi **nama petugas**. Coba **Isi data contoh** untuk melihat tampilan.
2. Tab **Barang** → tombol **+** untuk menambah barang (isi stok awal dan stok minimum).
3. Setiap ada barang datang atau dipakai: tombol **+ Barang masuk** / **− Pemakaian** di Beranda, atau buka barang lalu ketuk *Masuk* / *Pakai*.
4. Angka **masuk dan terpakai hari ini** langsung tampil di Beranda.

## Catatan data
- Data disimpan di browser HP (IndexedDB), tidak dikirim ke server mana pun. Jika data browser dihapus atau ganti HP, data hilang, jadi lakukan **Backup (JSON)** secara berkala dan **Pulihkan** di perangkat baru.
- Total "masuk/terpakai" di Beranda menjumlahkan angka dari semua barang, termasuk yang satuannya berbeda. Rincian per barang dan satuannya ada di daftar transaksi.

## Mengubah aplikasi
- Warna: variabel di bagian atas `css/style.css`.
- Satuan dan batas peringatan kedaluwarsa (`EXPIRY_WARN_DAYS`): bagian atas `js/app.js`.
- Setelah mengubah file, naikkan versi `CACHE` di `sw.js` (mis. `labstock-v2`) supaya HP mengambil versi baru.

## Struktur
```
index.html            halaman utama
manifest.webmanifest  pengaturan install (nama, ikon, warna)
sw.js                 service worker (offline)
css/style.css         tampilan
js/app.js             logika aplikasi
icons/                logo (SVG) dan ikon PNG 48/180/192/512 + maskable
.github/workflows/    deploy otomatis ke GitHub Pages
```

## Jadi APK (opsional)
Masukkan alamat GitHub Pages ke https://www.pwabuilder.com untuk membuat paket Android (APK/AAB).
